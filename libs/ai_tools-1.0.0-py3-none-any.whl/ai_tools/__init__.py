"""AI Tools - A lightweight AI library for API providers"""

from .utils.config import get_api_key
from .llm import LLMFactory
from .embeddings import EmbeddingFactory
from .vectorstore import VectorStoreFactory
from .tools import WebScraper

__version__ = "1.0.0"

__all__ = [
    'get_api_key',
    'LLMFactory',
    'EmbeddingFactory', 
    'VectorStoreFactory',
    'WebScraper',
]

