"""Version information for ai_tools package."""

__version__ = "1.0.0"
__version_info__ = (1, 0, 0)
