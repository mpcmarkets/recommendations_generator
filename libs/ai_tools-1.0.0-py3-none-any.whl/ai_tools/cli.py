#!/usr/bin/env python3
"""
Command-line interface for ai_tools
"""

import argparse
import sys
from typing import Optional

from .llm import LLMFactory
from .embeddings import EmbeddingFactory
from .vectorstore import VectorStoreFactory
from .tools import WebScraper


def main() -> None:
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="AI Tools - A comprehensive AI library for LLM providers, embeddings, and vector stores"
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # LLM command
    llm_parser = subparsers.add_parser('llm', help='LLM operations')
    llm_parser.add_argument('--prompt', '-p', required=True, help='Prompt to send to LLM')
    llm_parser.add_argument('--provider', help='LLM provider to use')
    llm_parser.add_argument('--model', help='Specific model to use')
    llm_parser.add_argument('--max-tokens', type=int, default=1000, help='Maximum tokens to generate')
    llm_parser.add_argument('--temperature', type=float, default=0.7, help='Temperature for generation')
    
    # Embeddings command
    embed_parser = subparsers.add_parser('embed', help='Generate embeddings')
    embed_parser.add_argument('--text', '-t', required=True, help='Text to embed')
    embed_parser.add_argument('--provider', default='openai', help='Embedding provider to use')
    embed_parser.add_argument('--model', help='Specific embedding model to use')
    
    # Vector store command
    vector_parser = subparsers.add_parser('vector', help='Vector store operations')
    vector_subparsers = vector_parser.add_subparsers(dest='vector_action', help='Vector store actions')
    
    # Add documents to vector store
    add_parser = vector_subparsers.add_parser('add', help='Add documents to vector store')
    add_parser.add_argument('--store', default='faiss', help='Vector store type')
    add_parser.add_argument('--documents', nargs='+', required=True, help='Documents to add')
    add_parser.add_argument('--dimension', type=int, default=1536, help='Vector dimension')
    
    # Search vector store
    search_parser = vector_subparsers.add_parser('search', help='Search vector store')
    search_parser.add_argument('--store', default='faiss', help='Vector store type')
    search_parser.add_argument('--query', required=True, help='Search query')
    search_parser.add_argument('--k', type=int, default=5, help='Number of results to return')
    search_parser.add_argument('--dimension', type=int, default=1536, help='Vector dimension')
    
    # Version command
    version_parser = subparsers.add_parser('version', help='Show version information')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    try:
        if args.command == 'llm':
            handle_llm_command(args)
        elif args.command == 'embed':
            handle_embed_command(args)
        elif args.command == 'vector':
            handle_vector_command(args)
        elif args.command == 'version':
            handle_version_command()
        else:
            parser.print_help()
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def handle_llm_command(args) -> None:
    """Handle LLM command"""
    factory = LLMFactory()
    
    if args.provider:
        llm = factory.get_llm(args.provider, model_name=args.model)
    else:
        llm = factory.select_best_model()
    
    response = llm.invoke(args.prompt)
    response_text = response.content if hasattr(response, 'content') else str(response)
    print(response_text)


def handle_embed_command(args) -> None:
    """Handle embedding command"""
    factory = EmbeddingFactory()
    embedder = factory.get_provider(args.provider, model=args.model)
    
    embeddings = embedder.embed([args.text])
    print(f"Embedding dimensions: {len(embeddings[0])}")
    print(f"First 5 values: {embeddings[0][:5]}")


def handle_vector_command(args) -> None:
    """Handle vector store command"""
    factory = VectorStoreFactory()
    
    if args.vector_action == 'add':
        vector_store = factory.get_store(args.store, dimension=args.dimension)
        # For demo purposes, create dummy embeddings
        import numpy as np
        embeddings = np.random.random((len(args.documents), args.dimension)).tolist()
        vector_store.add_documents(args.documents, embeddings)
        print(f"Added {len(args.documents)} documents to {args.store} vector store")
    
    elif args.vector_action == 'search':
        vector_store = factory.get_store(args.store, dimension=args.dimension)
        # For demo purposes, create dummy query embedding
        import numpy as np
        query_embedding = np.random.random(args.dimension).tolist()
        results = vector_store.search(query_embedding, k=args.k)
        print(f"Found {len(results)} results:")
        for i, result in enumerate(results, 1):
            print(f"{i}. {result}")
    
    else:
        print("Please specify an action: add or search")


def handle_version_command() -> None:
    """Handle version command"""
    try:
        from .__version__ import __version__
        print(f"ai_tools version {__version__}")
    except ImportError:
        print("ai_tools version 1.0.0")


if __name__ == '__main__':
    main()
