"""
Simplified Embedding Factory for API providers only
"""

import logging
from typing import Dict, List, Optional, Type, Any
import os

from ..utils.logger import setup_logger
from ..utils.config import get_api_key, get_api_base

# Set up logger
logger = setup_logger(__name__)

class EmbeddingProviderConfig:
    """Configuration for an embedding provider"""
    def __init__(
        self,
        name: str,
        model_name: str,
        dimensions: int = 1536,
        api_base: Optional[str] = None,
        timeout: int = 30,
        priority: int = 0,
        model_kwargs: Optional[Dict[str, Any]] = None,
        encode_kwargs: Optional[Dict[str, Any]] = None
    ):
        self.name = name
        self.model_name = model_name
        self.api_base = api_base or get_api_base(name)
        self.dimensions = dimensions
        self.timeout = timeout
        self.priority = priority
        self.model_kwargs = model_kwargs or {}
        self.encode_kwargs = encode_kwargs or {}

class EmbeddingProvider:
    """Base class for embedding providers"""
    
    def __init__(self, config: EmbeddingProviderConfig, api_key: Optional[str] = None):
        self.config = config
        self.api_key = api_key or get_api_key(config.name)
    
    def embed(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for a list of texts"""
        raise NotImplementedError("Subclasses must implement embed()")
    
    def test_availability(self) -> bool:
        """Tests if the API is available and working"""
        raise NotImplementedError("Subclasses must implement test_availability()")

class OpenAIEmbeddingProvider(EmbeddingProvider):
    """OpenAI embedding provider"""
    
    def __init__(self, config: EmbeddingProviderConfig, api_key: Optional[str] = None):
        super().__init__(config, api_key)
        if not self.api_key:
            raise ValueError("OpenAI API key is required")
    
    def embed(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings using OpenAI API"""
        try:
            import openai
            
            client = openai.OpenAI(api_key=self.api_key)
            
            response = client.embeddings.create(
                model=self.config.model_name,
                input=texts
            )
            
            return [embedding.embedding for embedding in response.data]
            
        except ImportError:
            raise ImportError("OpenAI package is required. Install with: pip install openai")
        except Exception as e:
            logger.error(f"OpenAI embedding error: {e}")
            raise
    
    def test_availability(self) -> bool:
        """Test OpenAI API availability"""
        try:
            self.embed(["test"])
            return True
        except:
            return False

class EmbeddingFactory:
    """Factory for creating embedding providers"""
    
    def __init__(self):
        self.providers = {
            'openai': OpenAIEmbeddingProvider,
        }
        
        # Default configurations
        self.configs = {
            'openai': EmbeddingProviderConfig(
                name='openai',
                model_name='text-embedding-3-small',
                dimensions=1536,
                priority=1
            ),
        }
    
    def get_provider(self, provider_name: str, model: Optional[str] = None) -> EmbeddingProvider:
        """Get an embedding provider instance"""
        if provider_name not in self.providers:
            raise ValueError(f"Unknown embedding provider: {provider_name}")
        
        config = self.configs[provider_name]
        if model:
            config = EmbeddingProviderConfig(
                name=config.name,
                model_name=model,
                dimensions=config.dimensions,
                api_base=config.api_base,
                timeout=config.timeout,
                priority=config.priority,
                model_kwargs=config.model_kwargs,
                encode_kwargs=config.encode_kwargs
            )
        
        provider_class = self.providers[provider_name]
        return provider_class(config)
    
    def get_available_providers(self) -> List[str]:
        """Get list of available providers"""
        available = []
        for name, provider_class in self.providers.items():
            try:
                config = self.configs[name]
                provider = provider_class(config)
                if provider.test_availability():
                    available.append(name)
            except:
                continue
        return available
    
    def get_best_provider(self) -> Optional[EmbeddingProvider]:
        """Get the best available provider based on priority"""
        available = self.get_available_providers()
        if not available:
            return None
        
        # Sort by priority (higher is better)
        available.sort(key=lambda x: self.configs[x].priority, reverse=True)
        return self.get_provider(available[0])