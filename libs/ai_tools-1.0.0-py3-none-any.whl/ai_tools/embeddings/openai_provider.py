import requests
from typing import Dict, List, Optional, Any
import logging
from pydantic import SecretStr

from langchain_openai import OpenAIEmbeddings
from langchain_core.embeddings import Embeddings

from ..utils.logger import setup_logger
from .factory import EmbeddingProvider, EmbeddingProviderConfig

# Set up logger
logger = setup_logger(__name__)

class OpenAIEmbeddingProvider(EmbeddingProvider):
    """Provider for OpenAI embeddings"""
    
    def get_embeddings(self, model_name: Optional[str] = None) -> Embeddings:
        """
        Returns a configured OpenAI Embeddings instance
        
        Args:
            model_name: Optional model name to override the default
        """
        return OpenAIEmbeddings(
            model=model_name or self.config.model_name,
            api_key=SecretStr(self.api_key) if self.api_key else None
        )
    
    def test_availability(self) -> bool:
        """Test if OpenAI API is available"""
        if not self.api_key:
            logger.warning("OpenAI API key not found")
            return False
            
        try:
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            response = requests.get(
                "https://api.openai.com/v1/models", 
                headers=headers, 
                timeout=self.config.timeout
            )
            
            if response.status_code == 200:
                return True
            else:
                logger.warning(f"OpenAI API test failed with status code: {response.status_code}")
                return False
        except Exception as e:
            logger.warning(f"OpenAI API test failed: {str(e)}")
            return False
    
    def get_available_models(self) -> List[str]:
        """Returns a list of available embedding models from OpenAI"""
        try:
            if not self.api_key:
                return [self.config.model_name]
                
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            response = requests.get(
                "https://api.openai.com/v1/models", 
                headers=headers, 
                timeout=self.config.timeout
            )
            
            if response.status_code == 200:
                models_data = response.json().get('data', [])
                # Filter for embedding models only
                embedding_models = [
                    model.get('id') for model in models_data 
                    if model.get('id') and ('embedding' in model.get('id') or model.get('id').startswith('text-embedding-'))
                ]
                return embedding_models if embedding_models else [self.config.model_name]
            else:
                return [self.config.model_name]
        except Exception:
            return [self.config.model_name]

    def get_model_details(self) -> List[Dict[str, Any]]:
        """Returns detailed information about available embedding models from OpenAI"""
        try:
            if not self.api_key:
                return [{"id": self.config.model_name, "dimensions": self.config.dimensions}]
                
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            response = requests.get(
                "https://api.openai.com/v1/models", 
                headers=headers, 
                timeout=self.config.timeout
            )
            
            if response.status_code == 200:
                models_data = response.json().get('data', [])
                # Filter for embedding models only and add dimensions
                embedding_models = []
                for model in models_data:
                    model_id = model.get('id')
                    if model_id and ('embedding' in model_id or model_id.startswith('text-embedding-')):
                        dimensions = self.config.dimensions  # Default
                        
                        # Set dimensions based on known models
                        if 'ada' in model_id or 'text-embedding-ada' in model_id:
                            dimensions = 1536
                        elif 'text-embedding-3-small' in model_id:
                            dimensions = 1536
                        elif 'text-embedding-3-large' in model_id:
                            dimensions = 3072
                        
                        embedding_models.append({
                            "id": model_id,
                            "dimensions": dimensions,
                            **{k:v for k,v in model.items() if k != 'id'}
                        })
                
                return embedding_models if embedding_models else [{"id": self.config.model_name, "dimensions": self.config.dimensions}]
            else:
                return [{"id": self.config.model_name, "dimensions": self.config.dimensions}]
        except Exception:
            return [{"id": self.config.model_name, "dimensions": self.config.dimensions}] 