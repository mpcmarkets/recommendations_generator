import requests
from typing import Dict, List, Optional, Any
import logging
from pydantic import SecretStr

from langchain_openai import ChatOpenAI

from ..utils.logger import setup_logger
from .factory import ModelProvider, ProviderConfig

# Set up logger
logger = setup_logger(__name__)

class DeepseekProvider(ModelProvider):
    """Provider for Deepseek models"""
    
    def get_llm(self, model_name: Optional[str] = None, **kwargs) -> ChatOpenAI:
        """
        Returns a configured Deepseek LLM instance
        
        Args:
            model_name: Optional model name to override the default
            **kwargs: Additional parameters to pass to the LLM constructor
        """
        # Override config with provided parameters
        model = model_name or self.config.model_name
        temperature = kwargs.get('temperature', self.config.temperature)
        max_tokens = kwargs.get('max_tokens', self.config.max_tokens)
        
        return ChatOpenAI(
            model=model,
            temperature=temperature,
            max_completion_tokens=max_tokens,
            base_url=self.config.api_base,
            api_key=SecretStr(self.api_key) if self.api_key else None,
            **{k: v for k, v in kwargs.items() if k not in ['temperature', 'max_completion_tokens']}
        )
    
    def test_availability(self) -> bool:
        """Test if Deepseek API is available using a lightweight models list request"""
        if not self.api_key:
            logger.warning("Deepseek API key not found")
            return False
            
        try:
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            response = requests.get(
                f"{self.config.api_base}/models", 
                headers=headers, 
                timeout=self.config.timeout
            )
            
            if response.status_code == 200:
                return True
            else:
                logger.warning(f"Deepseek API test failed with status code: {response.status_code}")
                return False
        except Exception as e:
            logger.warning(f"Deepseek API test failed: {str(e)}")
            return False
    
    def get_available_models(self) -> List[str]:
        """Returns a list of available models from Deepseek"""
        try:
            if not self.api_key:
                return [self.config.model_name]
                
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            response = requests.get(
                f"{self.config.api_base}/models", 
                headers=headers, 
                timeout=self.config.timeout
            )
            
            if response.status_code == 200:
                models_data = response.json().get('data', [])
                return [model.get('id') for model in models_data if model.get('id')]
            else:
                return [self.config.model_name]
        except Exception as e:
            logger.warning(f"Error fetching Deepseek models: {str(e)}")
            return [self.config.model_name]

    def get_model_details(self) -> List[Dict[str, Any]]:
        """Returns detailed information about available models from Deepseek"""
        try:
            if not self.api_key:
                return [{"id": self.config.model_name}]
            
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            response = requests.get(
                f"{self.config.api_base}/models", 
                headers=headers, 
                timeout=self.config.timeout
            )
            
            if response.status_code == 200:
                return response.json().get('data', [])
            else:
                return [{"id": self.config.model_name}]
        except Exception as e:
            logger.warning(f"Error fetching Deepseek model details: {str(e)}")
            return [{"id": self.config.model_name}] 