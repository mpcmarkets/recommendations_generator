import logging
from typing import Dict, List, Optional, Type, Union, Any, Tuple
import os

from langchain_openai import ChatOpenAI

from ..utils.logger import setup_logger
from ..utils.config import get_api_key, get_api_base, API_BASE_URLS
# Import from router
from .router import ModelAttributes, MODEL_ROUTER_TABLE

# Set up logger
logger = setup_logger(__name__)

class ProviderConfig:
    """Configuration for a model provider"""
    def __init__(
        self,
        name: str,
        model_name: str,
        temperature: float = 0.7,
        max_tokens: int = 4000,
        api_base: Optional[str] = None,
        timeout: int = 5,
        priority: int = 0
    ):
        self.name = name
        self.model_name = model_name
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.api_base = api_base or get_api_base(name)
        self.timeout = timeout
        self.priority = priority

class ModelProvider:
    """Base class for model providers"""
    
    def __init__(self, config: ProviderConfig, api_key: Optional[str] = None):
        self.config = config
        # Use provided API key or get from the hardcoded keys
        self.api_key = api_key or get_api_key(config.name)
    
    def get_llm(self, model_name: Optional[str] = None, **kwargs) -> ChatOpenAI:
        """
        Returns a configured LLM instance
        
        Args:
            model_name: Optional model name to override the default
            **kwargs: Additional parameters to pass to the LLM constructor
        """
        raise NotImplementedError("Subclasses must implement get_llm()")
    
    def test_availability(self) -> bool:
        """Tests if the API is available and working"""
        raise NotImplementedError("Subclasses must implement test_availability()")
    
    def get_available_models(self) -> List[str]:
        """Returns a list of available models for this provider"""
        return [self.config.model_name]

    def get_model_details(self) -> List[Dict[str, Any]]:
        """Returns detailed information about available models"""
        return [{"id": self.config.model_name}]

# Import provider implementations
from .openrouter_provider import OpenRouterProvider
from .deepseek_provider import DeepseekProvider
from .perplexity_provider import PerplexityProvider
from .openai_provider import OpenAIProvider

# Provider registry - maps provider names to their classes
MODEL_PROVIDER_REGISTRY: Dict[str, Type[ModelProvider]] = {
    "openrouter": OpenRouterProvider,
    "deepseek": DeepseekProvider,
    "perplexity": PerplexityProvider,
    "openai": OpenAIProvider,
}

# Default configurations for each provider
DEFAULT_PROVIDER_CONFIGS: Dict[str, ProviderConfig] = {
    "openrouter": ProviderConfig(
        name="openrouter",
        model_name="microsoft/mai-ds-r1:free",
        api_base=API_BASE_URLS["openrouter"],
        priority=3,  # Highest priority
    ),
    "deepseek": ProviderConfig(
        name="deepseek",
        model_name="deepseek-reasoner",
        api_base=API_BASE_URLS["deepseek"],
        priority=2,
    ),
    "perplexity": ProviderConfig(
        name="perplexity",
        model_name="sonar",
        api_base=API_BASE_URLS["perplexity"],
        priority=1,
    ),
    "openai": ProviderConfig(
        name="openai",
        model_name="o4-mini",
        temperature=1.0,
        max_tokens=16000,
        api_base=API_BASE_URLS["openai"],
        priority=1,  # Lowest priority
    ),
}

class LLMFactory:
    """Factory for creating LLM instances from different providers"""
    
    def __init__(
        self, 
        configs: Optional[Dict[str, ProviderConfig]] = None,
        api_keys: Optional[Dict[str, str]] = None
    ):
        """
        Initialize the factory with provider configurations and API keys
        
        Args:
            configs: Optional dictionary of provider configurations to override defaults
            api_keys: Optional dictionary of API keys for providers (e.g., {"openai": "sk-..."})
        """
        self.configs = DEFAULT_PROVIDER_CONFIGS.copy()
        if configs:
            self.configs.update(configs)
        
        # Use provided API keys or empty dict (will use environment variables)
        self.api_keys = api_keys or {}
        logger.info(f"Initialized LLMFactory for: {', '.join(self.configs.keys())}")
    
    def get_available_providers(self) -> List[str]:
        """
        Get a list of available model providers that have valid API keys
        
        Returns:
            List of provider names that are available
        """
        available = []
        for provider_name in MODEL_PROVIDER_REGISTRY:
            provider = self.get_provider(provider_name)
            if provider and provider.test_availability():
                available.append(provider_name)
        return available
    
    def get_provider(self, provider_name: str) -> Optional[ModelProvider]:
        """
        Get a provider instance by name
        
        Args:
            provider_name: Name of the provider to get
            
        Returns:
            ModelProvider instance or None if not found
        """
        if provider_name not in MODEL_PROVIDER_REGISTRY:
            logger.warning(f"Model provider '{provider_name}' not found in registry")
            return None
            
        provider_class = MODEL_PROVIDER_REGISTRY[provider_name]
        config = self.configs.get(provider_name)
        
        if not config:
            logger.warning(f"No configuration found for model provider '{provider_name}'")
            return None
        
        # Use API key from api_keys dict
        api_key = self.api_keys.get(provider_name)
        return provider_class(config, api_key=api_key)

    def get_available_llms(self, provider_name: str) -> List[str]:
        """
        Get a list of available models for a specific provider
        
        Args:
            provider_name: Name of the provider
            
        Returns:
            List of model names available for the provider
        """
        provider = self.get_provider(provider_name)
        if provider and provider.test_availability():
            return provider.get_available_models()
        return []
    
    def get_llm_details(self, provider_name: str) -> List[Dict[str, Any]]:
        """
        Get detailed information about available models for a specific provider
        
        Args:
            provider_name: Name of the provider
            
        Returns:
            List of dictionaries with model details
        """
        provider = self.get_provider(provider_name)
        if provider and provider.test_availability():
            return provider.get_model_details()
        return []
    
    def get_llm(self, provider_name: str, model_name: Optional[str] = None, **kwargs) -> ChatOpenAI:
        """
        Get a specific LLM instance from the specified provider.

        This method directly attempts to instantiate the requested model.
        It requires the provider name. If model_name is not specified,
        it attempts to use the default model for that provider.

        Args:
            provider_name: Name of the provider to use.
            model_name: Optional specific model name to use.
            **kwargs: Additional parameters to pass to the LLM constructor.

        Returns:
            A configured ChatOpenAI instance.

        Raises:
            ValueError: If the provider is not found or not configured.
            RuntimeError: If the provider is not available (e.g., API key issue, network error) 
                         or fails to instantiate the model.
            Exception: Other potential exceptions from the underlying provider's get_llm method.
        """
        provider = self.get_provider(provider_name)
        
        if not provider:
            raise ValueError(f"Provider '{provider_name}' not found or not configured.")

        # Determine the model name to use (specified or provider's default)
        target_model_name = model_name or provider.config.model_name

        # Check availability before attempting to get LLM
        # Note: Some provider.get_llm implementations might handle this, 
        # but checking upfront provides a clearer error point.
        if not provider.test_availability():
             raise RuntimeError(f"Provider '{provider_name}' is configured but currently unavailable.")

        try:
            llm_instance = provider.get_llm(model_name=target_model_name, **kwargs)
            logger.info(f"Successfully instantiated model '{target_model_name}' from '{provider_name}'")
            return llm_instance
        except NotImplementedError:
             logger.error(f"Provider '{provider_name}' does not implement get_llm().")
             raise RuntimeError(f"Provider '{provider_name}' cannot instantiate models.")
        except Exception as e:
            logger.error(f"Failed to get LLM instance for model '{target_model_name}' from provider '{provider_name}': {e}", exc_info=True)
            # Re-raise the exception to signal failure
            raise RuntimeError(f"Failed to instantiate model '{target_model_name}' from '{provider_name}'. Reason: {e}") from e

    def select_best_model(
        self,
        min_intelligence: int = 5,
        min_speed: int = 5,
        min_context_window: int = 20000,
        max_cost: int = 0,
        preferred_provider: Optional[str] = None,
        **kwargs: Any  # Pass kwargs to the underlying get_llm call
    ) -> ChatOpenAI:
        """
        Selects and instantiates the best available model based on specified criteria.

        Filters models from MODEL_ROUTER_TABLE based on criteria, sorts them by preference
        (cost, intelligence), and attempts to instantiate the first available one using `get_llm`.

        Args:
            min_intelligence: Minimum intelligence score (0-10).
            min_speed: Minimum speed score (0-10).
            min_context_window: Minimum context window size (tokens).
            max_cost: Maximum cost score (0-10).
            preferred_provider: If specified, only consider models from this provider.
            **kwargs: Additional arguments to pass to the final `get_llm` call (e.g., temperature).

        Returns:
            A ChatOpenAI instance of the best matching available model, or None if no suitable
            and available model can be instantiated.
        """
        candidates = []
        for attributes in MODEL_ROUTER_TABLE.values():
            # Filter based on criteria
            if (
                attributes.intelligence >= min_intelligence and
                attributes.speed >= min_speed and
                attributes.context_window_tokens >= min_context_window and
                attributes.cost <= max_cost and
                (preferred_provider is None or attributes.provider == preferred_provider)
            ):
                 # Check if the provider is configured in this factory instance
                 if attributes.provider in self.configs:
                     candidates.append(attributes)
                 else:
                     logger.debug(f"Skipping candidate {attributes.model_name} from provider {attributes.provider}: Provider not configured in factory.")

        if not candidates:
            logger.warning("No configured models found matching the criteria in the router table.")
            raise RuntimeError("No configured models found matching the criteria in the router table.")

        # Sort candidates: prioritize lower cost, then higher intelligence
        candidates.sort(key=lambda x: (x.cost, -x.intelligence))

        # Attempt to instantiate the sorted candidates using get_llm
        for candidate in candidates:
            try:
                llm_instance = self.get_llm(
                    provider_name=candidate.provider,
                    model_name=candidate.model_name,
                    **kwargs # Pass through any additional args
                )
                # If get_llm succeeds, we found our best available model
                logger.info(f"Successfully selected and instantiated best model: {candidate.model_name} from {candidate.provider}")
                return llm_instance
            except (ValueError, RuntimeError) as e:
                 # These errors are expected if a provider is unavailable or model fails
                 logger.debug(f"Candidate {candidate.model_name} ({candidate.provider}) failed selection: {e}")
            except Exception as e:
                 # Catch unexpected errors during instantiation attempt
                 logger.error(f"Unexpected error selecting candidate {candidate.model_name} ({candidate.provider}): {e}", exc_info=True)

        logger.warning("No available model provider could be instantiated for the models matching the criteria.")
        raise RuntimeError("No available model provider could be instantiated for the models matching the criteria.")