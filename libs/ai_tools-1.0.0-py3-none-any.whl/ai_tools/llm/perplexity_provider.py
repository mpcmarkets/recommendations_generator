import requests
from typing import Dict, List, Optional, Any
import logging
import json
import os
from pydantic import SecretStr

from langchain_community.chat_models import ChatPerplexity

from ..utils.logger import setup_logger
from .factory import ModelProvider, ProviderConfig

# Set up logger
logger = setup_logger(__name__)

class PerplexityProvider(ModelProvider):
    """Provider for Perplexity models.
    
    Uses the langchain_community ChatPerplexity implementation which is
    specifically designed for the Perplexity API.
    """
    
    def get_llm(self, model_name: Optional[str] = None, **kwargs) -> ChatPerplexity:
        """
        Returns a configured Perplexity LLM instance using ChatPerplexity from langchain_community.
        
        Args:
            model_name: Optional model name to override the default
            **kwargs: Additional parameters to pass to the LLM constructor
        """
        # Override config with provided parameters
        model = model_name or self.config.model_name
        temperature = kwargs.get('temperature', self.config.temperature)
        max_tokens = kwargs.get('max_tokens', self.config.max_tokens)
        timeout = kwargs.get('timeout', 60)  # Default timeout of 60 seconds
        
        # Create the LLM with ChatPerplexity implementation
        llm = ChatPerplexity(
            model=model,
            temperature=temperature,
            max_tokens=max_tokens,
            api_key=self.api_key,
            timeout=timeout,
            **{k: v for k, v in kwargs.items() if k not in ['temperature', 'max_tokens', 'timeout']}
        )
        return llm
    
    def test_availability(self) -> bool:
        """Test if Perplexity API is available by making a small test call."""
        if not self.api_key:
            logger.warning("Perplexity API key not found")
            return False
            
        try:            
            url = "https://api.perplexity.ai/chat/completions"

            payload = {
                "model": "sonar",
                "messages": [
                    {
                        "role": "user",
                        "content": "Test"
                    }
                ],
                "max_tokens": 10,
                "temperature": 1,
            }
            headers = {
                "Authorization": f"Bearer {self.api_key}",
            }

            response = requests.request("POST", url, json=payload, headers=headers)
            
            # Check if response content is not empty (basic success check)
            if response.status_code == 200:
                return True
            else:
                logger.warning(f"Perplexity API test failed with status code: {response.status_code}")
                return False
                
        except Exception as e:
            logger.warning(f"Perplexity API test failed: {str(e)}")
            # Log the full exception details for better debugging
            logger.exception("Exception details:") 
            return False
    
    def get_available_models(self) -> List[str]:
        """Returns a list of available models from Perplexity.
        Perplexity doesn't have a standard /models endpoint, so we return a static list 
        based on their documentation: https://docs.perplexity.ai/guides/model-cards
        """
        return [
            "sonar", # Lightweight search
            "sonar-pro", # Advanced search
            "sonar-deep-research", # Expert-level research
            "sonar-reasoning", # Fast reasoning with search
            "sonar-reasoning-pro", # Premier reasoning (DeepSeek R1)
            "r1-1776" # Offline chat (DeepSeek R1)
        ]

    def get_model_details(self) -> List[Dict[str, Any]]:
        """Returns detailed information about available models from Perplexity.
        Returns static details based on documentation as Perplexity's API structure differs.
        Reference: https://docs.perplexity.ai/guides/model-cards
        """
        return [
            {
                "id": "sonar", 
                "description": "Lightweight, cost-effective search model with grounding. Best for quick factual queries."
            },
            {
                "id": "sonar-pro", 
                "description": "Advanced search offering with grounding, supporting complex queries and follow-ups. Max 8k output tokens."
            },
            {
                "id": "sonar-deep-research", 
                "description": "Expert-level research model conducting exhaustive searches and generating comprehensive reports. Can take 30+ mins."
            },
            {
                "id": "sonar-reasoning", 
                "description": "Fast, real-time reasoning model designed for quick problem-solving with search."
            },
            {
                "id": "sonar-reasoning-pro", 
                "description": "Premier reasoning offering powered by DeepSeek R1 with Chain of Thought (CoT)."
            },
            {
                "id": "r1-1776", 
                "description": "Offline chat model (DeepSeek R1). Uncensored, unbiased, factual. No search."
            }
        ]
