import dataclasses
from typing import Dict, Optional

@dataclasses.dataclass
class ModelAttributes:
    """Represents the attributes of an LLM model for routing purposes."""
    intelligence: int  # Scale 0-10 (0=lowest, 10=highest)
    speed: int         # Scale 0-10 (0=slowest, 10=fastest)
    context_window_tokens: int
    cost: int          # Scale 0-10 (0=free, 10=most expensive)
    provider: str      # The name of the provider (e.g., 'openai', 'openrouter')
    model_name: str    # The specific model name used by the provider API

MODEL_ROUTER_TABLE: Dict[str, ModelAttributes] = {
    "openrouter-deepseek-chat-v3.1": ModelAttributes(
        intelligence=8,
        speed=6,
        context_window_tokens=64000, 
        cost=0,          
        provider='openrouter',
        model_name='deepseek/deepseek-chat-v3.1:free'
    ),
    "openrouter-gpt-oss-120b": ModelAttributes(
        intelligence=6,
        speed=8,
        context_window_tokens=33000, 
        cost=0,          
        provider='openrouter',
        model_name='openai/gpt-oss-120b:free'
    ),
    "openrouter-o4-mini-high": ModelAttributes(
        intelligence=8,
        speed=8,
        context_window_tokens=128000, 
        cost=2,          
        provider='openrouter',
        model_name='openai/o4-mini-high'
    ),
    "openrouter-grok-3-mini-beta": ModelAttributes(
        intelligence=8,
        speed=9,
        context_window_tokens=131000, 
        cost=1,          
        provider='openrouter',
        model_name='x-ai/grok-3-mini-beta'
    ),
    "openrouter-gpt-4o-mini-search-preview": ModelAttributes(
        intelligence=8,
        speed=8,
        context_window_tokens=128000, 
        cost=2,          
        provider='openrouter',
        model_name='openai/gpt-4o-mini-search-preview'
    ),
    "openrouter-gemini-2.5-pro-preview-03-25": ModelAttributes(
        intelligence=8,
        speed=6,
        context_window_tokens=1000000, 
        cost=7,          
        provider='openrouter',
        model_name='google/gemini-2.5-pro-preview-03-25'
    ),
    "openrouter-claude-3.7-sonnet:thinking": ModelAttributes(
        intelligence=8,
        speed=6,
        context_window_tokens=200000, 
        cost=9,          
        provider='openrouter',
        model_name='anthropic/claude-3.7-sonnet:thinking'
    ),
    "openrouter-mai-ds-r1:free": ModelAttributes(
        intelligence=6,
        speed=5, 
        context_window_tokens=163840,
        cost=0,
        provider='openrouter',
        model_name='microsoft/mai-ds-r1:free'
    ),
    "openrouter-deepseek-r1-zero:free": ModelAttributes(
        intelligence=6,
        speed=4, 
        context_window_tokens=163840,
        cost=0,
        provider='openrouter',
        model_name='deepseek/deepseek-r1-zero:free'
    ),
    "openrouter-claude-3.7-sonnet": ModelAttributes(
        intelligence=7,
        speed=7,
        context_window_tokens=200000, 
        cost=9,          
        provider='openrouter',
        model_name='anthropic/claude-3.7-sonnet'
    ),
    "openrouter-gemini-2.0-flash-001": ModelAttributes(
        intelligence=6,
        speed=9,
        context_window_tokens=1000000, 
        cost=2,          
        provider='openrouter',
        model_name='google/gemini-2.0-flash-001'
    ),
    "openrouter-llama-4-maverick:free": ModelAttributes(
        intelligence=4,
        speed=6,
        context_window_tokens=256000, 
        cost=0,          
        provider='openrouter',
        model_name='meta-llama/llama-4-maverick:free'
    ),
    "openrouter-llama-4-scout:free": ModelAttributes(
        intelligence=3,
        speed=7,
        context_window_tokens=512000, 
        cost=0,          
        provider='openrouter',
        model_name='meta-llama/llama-4-scout:free'
    ),
    #### DeepSeek Models ####
    "deepseek-chat": ModelAttributes(
        intelligence=5,  # Was 'advanced'
        speed=4,         # Was 'medium'
        context_window_tokens=64000, # Needs verification for deepseek-chat specifically
        cost=3,          # Was 'cheap'
        provider='deepseek',
        model_name='deepseek-chat'
    ),
    "deepseek-reasoner": ModelAttributes(
        intelligence=6,  # Was 'advanced'
        speed=2,         # Was 'medium'
        context_window_tokens=163840, # Needs verification for deepseek-chat specifically
        cost=3,          # Was 'cheap'
        provider='deepseek',
        model_name='deepseek-reasoner'
    ),
    #### OpenAI Models ####
    "openai-o4-mini": ModelAttributes(
        intelligence=8, # Was 'state-of-the-art'
        speed=8,         # Was 'fast'
        context_window_tokens=128000,  # From factory config
        cost=2,          # Was 'moderate'
        provider='openai',
        model_name='o4-mini'
    ),
    "openai-o3-mini": ModelAttributes(
        intelligence=7, # Was 'state-of-the-art'
        speed=8,         # Was 'fast'
        context_window_tokens=128000,  # From factory config
        cost=2,          # Was 'moderate'
        provider='openai',
        model_name='o3-mini'
    ),
    "openai-gpt-4.1": ModelAttributes(
        intelligence=7, # Was 'state-of-the-art'
        speed=8,         # Was 'fast'
        context_window_tokens=128000,  # From factory config
        cost=5,          # Was 'moderate'
        provider='openai',
        model_name='gpt-4.1'
    ),
    "openai-gpt-4o": ModelAttributes(
        intelligence=5, # Was 'state-of-the-art'
        speed=8,         # Was 'fast'
        context_window_tokens=128000,  # From factory config
        cost=7,          # Was 'moderate'
        provider='openai',
        model_name='gpt-4o'
    ),
}

# Example function demonstrating how to select a model (to be integrated into LLMFactory)
def select_model_based_on_criteria(
    min_intelligence: int = 5,   # Default: intermediate or better
    min_speed: int = 5,          # Default: medium or faster
    min_context_window: int = 10000,
    max_cost: int = 0,           # Default: moderate or cheaper
    preferred_provider: Optional[str] = None,
) -> Optional[ModelAttributes]:
    """
    Selects the 'best' model from the table based on criteria.
    'Best' is subjective and currently prioritizes meeting criteria, then lower cost, then higher intelligence.
    Assumes scales are 0-10 (higher is better/faster/more expensive).
    """
    candidates = []
    for attributes in MODEL_ROUTER_TABLE.values():
        # Check if provider exists and is available (integration point with LLMFactory needed here)
        # For now, just filter based on attributes
        if (
            attributes.intelligence >= min_intelligence and
            attributes.speed >= min_speed and
            attributes.context_window_tokens >= min_context_window and
            attributes.cost <= max_cost and
            (preferred_provider is None or attributes.provider == preferred_provider)
        ):
            candidates.append(attributes)

    if not candidates:
        return None

    # Sort candidates: prioritize lower cost, then higher intelligence
    candidates.sort(key=lambda x: (x.cost, -x.intelligence))

    return candidates[0]
