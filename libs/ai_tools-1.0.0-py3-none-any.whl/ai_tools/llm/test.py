import json
import time
import os
from datetime import datetime
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger("llm_test")

# --- Import your actual LLM Factory ---
# Make sure this import path is correct for your project structure
try:
    # !!! Replace with the correct import path for your LLMFactory !!!
    from mpcmarkets.ai.llm.factory import LLMFactory
except ImportError:
    logger.error("Could not import LLMFactory. Please ensure 'mpcmarkets.ai.llm.factory' is installed.")
    exit(1)

# --- Configuration ---
CONFIG = {
    "provider_name": "openrouter",
    "processor_model": "microsoft/mai-ds-r1:free",
    "delay_between_calls": 0,
    "output_provider_name": "openrouter",
    "target_models": [
        "openai/o4-mini-high",
        "openai/gpt-4o-mini-search-preview",
        "google/gemini-2.5-pro-preview-03-25",
        "anthropic/claude-3.7-sonnet:thinking",
        "microsoft/mai-ds-r1:free",
        "deepseek/deepseek-r1-zero:free",
        "anthropic/claude-3.7-sonnet",
        "google/gemini-2.0-flash-001",
        "meta-llama/llama-4-maverick:free",
        "meta-llama/llama-4-scout:free",
        "thudm/glm-z1-rumination-32b"
    ]
}

def setup_llm_factory():
    """Initialize the LLM factory and return the processor model."""
    logger.info("Initializing LLMFactory...")
    try:
        llmfactory = LLMFactory()
        logger.info("LLMFactory initialized successfully.")
        
        logger.info(f"Getting LLM processor: {CONFIG['processor_model']} from {CONFIG['provider_name']}...")
        llm_processor = llmfactory.get_llm(
            provider_name=CONFIG['provider_name'],
            model_name=CONFIG['processor_model']
        )
        logger.info(f"LLM processor obtained: {CONFIG['processor_model']}")
        
        # Verify the invocation method exists
        invocation_method = 'invoke'
        if not hasattr(llm_processor, invocation_method):
            available_methods = [m for m in dir(llm_processor) 
                              if not m.startswith('_') and callable(getattr(llm_processor, m))]
            logger.warning(f"Warning: LLM object doesn't have '{invocation_method}()' method.")
            logger.warning(f"Available methods: {', '.join(available_methods)}")
        
        return llmfactory, llm_processor, invocation_method
    
    except Exception as e:
        logger.error(f"Error setting up LLM: {e}")
        exit(1)

def get_model_details(llmfactory, provider_name):
    """Fetch model details from the provider and create a lookup map."""
    logger.info(f"Fetching model details for provider: {provider_name}")
    
    try:
        all_llm_details = llmfactory.get_llm_details(provider_name=provider_name)
        
        if not isinstance(all_llm_details, list):
            logger.warning(f"get_llm_details did not return a list (got {type(all_llm_details)})")
            if all_llm_details is None:
                all_llm_details = []
        
        logger.info(f"Fetched details for {len(all_llm_details)} models")
        
        # Create lookup map
        details_map = {}
        for model_info in all_llm_details:
            if isinstance(model_info, dict) and 'id' in model_info:
                details_map[model_info['id']] = model_info
            else:
                logger.warning(f"Skipping invalid model entry: {str(model_info)[:100]}...")
        
        logger.info(f"Created lookup map for {len(details_map)} models")
        return details_map
    
    except Exception as e:
        logger.error(f"Error fetching model details: {e}")
        exit(1)

def create_transformation_prompt(model_details_json_str, target_provider):
    """Generate the LLM prompt for transforming model details into the target format."""
    prompt = f"""
You are an expert data transformation engine. Your task is to analyze the provided input JSON containing details about a specific Large Language Model (LLM), and transform it into the specified output JSON format. Pay close attention to data types and handling of missing values.

Input Data (Details of one LLM):
```json
{model_details_json_str}

Output JSON Format Required (Strictly adhere to this structure and keys):

{{
  "date_of_release": "YYYY-MM-DD" | null,
  "intelligence_index": <integer> | null,
  "input_context": <integer> | null,
  "output_context": <integer> | null,
  "input_cost": <float> | null,
  "output_cost": <float> | null,
  "provider": "{target_provider}",
  "type": "chat" | "thinking" | "websearch" | null
}}

Instructions for Transformation (Follow precisely):

date_of_release (String | Null):
Locate the created field in the input JSON. This is a Unix timestamp (seconds since epoch).
Convert this timestamp into a date string formatted as "YYYY-MM-DD".
If the created field is missing, invalid, or cannot be converted, set this to null.

intelligence_index (Integer | Null):
For internal calculation only (don't include in output), score these capabilities from 0-10:

reasoning (0-10):
- Look for mentions of reasoning, problem-solving, or step-by-step thinking
- Higher scores for advanced reasoning features like chain-of-thought or rumination 

knowledge (0-10):
- Assess knowledge breadth and depth from the description
- Higher scores for specialized domain knowledge or up-to-date information

specialized_tasks (0-10):
- Look for mentions of specific task optimization (coding, math, etc.)
- Higher scores for exceptional performance in specialized areas

contextual_understanding (0-10):
- Consider context window size and handling complexity
- Higher scores for larger context windows and better context processing

efficiency (0-10):
- Look for mentions of optimization, speed, or resource efficiency
- Higher scores for models explicitly optimized for performance

Calculate the intelligence_index as the sum of these scores multiplied by 2 (creating a value between 0-100).
If insufficient information is available for scoring, set intelligence_index to null.

input_context (Integer | Null):
Extract the context_length field from the top_provider object.
Set to null if missing or not a valid integer.

output_context (Integer | Null):
Extract the max_completion_tokens field from the top_provider object.
Set to null if missing or not a valid integer.

input_cost (Float | Null):
Find the prompt field inside the pricing object.
Convert to cost per million tokens by multiplying by 1,000,000.
Set to null if missing or invalid.

output_cost (Float | Null):
Find the completion field inside the pricing object.
Convert to cost per million tokens by multiplying by 1,000,000.
Set to null if missing or invalid.

provider (String):
Set to the constant value: "{target_provider}".

type (String | Null):
Determine the model type based on:
- "thinking": For step-by-step reasoning models (check name for "thinking" or description for reasoning features)
- "websearch": For models with search capabilities (check name for "search" or description for web access)
- "chat": For standard conversational models
- null: If type cannot be determined

CRITICAL: Your response MUST contain ONLY the final JSON object with no additional text.
"""
    return prompt

def process_llm_response(model_id, llm_output_raw):
    """Process the raw LLM response and extract a valid JSON object."""
    try:
        clean_output = llm_output_raw.strip()
        json_start = clean_output.find('{')
        json_end = clean_output.rfind('}')
        
        if json_start != -1 and json_end != -1 and json_end > json_start:
            json_string = clean_output[json_start:json_end + 1]
            parsed_json = json.loads(json_string)
            logger.info(f"Successfully parsed JSON response for {model_id}")
            return parsed_json, None
        else:
            error_msg = "Could not find valid JSON object boundaries in response"
            logger.error(f"{error_msg} for {model_id}")
            return None, error_msg
    
    except json.JSONDecodeError as e:
        logger.error(f"JSON parsing error for {model_id}: {e}")
        return None, f"Invalid JSON: {e}"
    
    except Exception as e:
        logger.error(f"Error processing response for {model_id}: {e}")
        return None, f"Processing error: {e}"

def validate_model_data(model_id, parsed_json):
    """Validate and clean up the parsed model data."""
    if not isinstance(parsed_json, dict):
        logger.error(f"Parsed result for {model_id} is not a dictionary")
        return parsed_json
    
    # Validate type field
    if "type" in parsed_json:
        valid_types = ["chat", "thinking", "websearch", None]
        if parsed_json["type"] not in valid_types:
            logger.warning(f"Invalid type '{parsed_json['type']}' for {model_id}. Setting to 'chat'")
            parsed_json["type"] = "chat"
    
    # Validate intelligence_index
    if "intelligence_index" in parsed_json and parsed_json["intelligence_index"] is not None:
        try:
            parsed_json["intelligence_index"] = max(0, min(100, int(parsed_json["intelligence_index"])))
        except (ValueError, TypeError):
            logger.warning(f"Invalid intelligence_index for {model_id}. Setting to null")
            parsed_json["intelligence_index"] = None
    
    # Remove internal calculation field if present
    if "capabilities_score" in parsed_json:
        del parsed_json["capabilities_score"]
    
    return parsed_json

def invoke_llm(llm_processor, invocation_method, prompt, model_id):
    """Call the LLM with the given prompt and handle response extraction."""
    logger.info(f"Sending request to LLM processor for {model_id}...")
    
    try:
        invoke_method = getattr(llm_processor, invocation_method)
        response = invoke_method(prompt)
        
        # Extract text from response based on its structure
        if hasattr(response, 'content') and isinstance(response.content, str):
            output = response.content
        elif isinstance(response, str):
            output = response
        elif hasattr(response, 'text') and isinstance(response.text, str):
            output = response.text
        else:
            output = str(response)
        
        logger.info(f"Received response ({len(output)} chars) for {model_id}")
        return output, None
    
    except AttributeError as e:
        error_msg = f"Method issue: {e}. Check if '{invocation_method}' is correct"
        logger.error(error_msg)
        return None, error_msg
    
    except Exception as e:
        error_msg = f"LLM invocation failed: {e}"
        logger.error(error_msg)
        return None, error_msg

def process_model(model_id, details_map, llm_processor, invocation_method):
    """Process a single model, transforming its details into the target format."""
    logger.info(f"Processing model: {model_id}")
    
    # Find details for current model
    model_details = details_map.get(model_id)
    if not model_details:
        logger.warning(f"Details not found for model ID: {model_id}")
        return {"error": "Model details not found in provider list"}
    
    # Serialize details to JSON string
    try:
        model_details_str = json.dumps(model_details, indent=2)
    except TypeError as e:
        logger.error(f"Could not serialize model details: {e}")
        return {"error": f"Could not serialize model details: {e}"}
    
    # Create prompt and call LLM
    prompt = create_transformation_prompt(model_details_str, CONFIG["output_provider_name"])
    
    # Invoke LLM
    llm_output, error = invoke_llm(llm_processor, invocation_method, prompt, model_id)
    if error:
        return {"error": error}
    
    # Process and validate response
    parsed_json, error = process_llm_response(model_id, llm_output)
    if error:
        return {"error": error, "raw_output": llm_output}
    
    # Validate and clean up the data
    validated_json = validate_model_data(model_id, parsed_json)
    return validated_json

def main():
    logger.info("Starting LLM model analysis script")
    
    # Set up factory and processor
    llmfactory, llm_processor, invocation_method = setup_llm_factory()
    
    # Get model details
    details_map = get_model_details(llmfactory, CONFIG["provider_name"])
    
    # Process each target model
    results = {}
    logger.info(f"Starting processing of {len(CONFIG['target_models'])} models")
    
    for model_id in CONFIG["target_models"]:
        results[model_id] = process_model(
            model_id, 
            details_map, 
            llm_processor, 
            invocation_method
        )
        
        # Delay between API calls
        if CONFIG["delay_between_calls"] > 0 and model_id != CONFIG["target_models"][-1]:
            logger.info(f"Waiting {CONFIG['delay_between_calls']}s before next request")
            time.sleep(CONFIG["delay_between_calls"])
    
    # Output results
    logger.info("Processing complete")
    print("\n--- Final Transformed JSON Outputs ---")
    print(json.dumps(results, indent=2))

if __name__ == "__main__":
    main()