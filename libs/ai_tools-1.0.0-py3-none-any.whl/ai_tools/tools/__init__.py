"""Tools module for ai_tools."""

from .webscraper import WebScraper

__all__ = [
    'WebScraper',
]
