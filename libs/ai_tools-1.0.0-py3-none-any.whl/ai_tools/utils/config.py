import os
from typing import Optional

# Load environment variables from .env file if it exists
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    # dotenv not available, continue without it
    pass

# Environment variable names for API keys
API_KEY_ENV_VARS = {
    "openai": "OPENAI_API_KEY",
    "openrouter": "OPENROUTER_API_KEY", 
    "deepseek": "DEEPSEEK_API_KEY",
    "perplexity": "PERPLEXITY_API_KEY",
    "huggingface": "HUGGINGFACE_API_KEY",
    "tavily": "TAVILY_API_KEY"
}

# API base URLs for different providers
API_BASE_URLS = {
    "ollama": "http://localhost:11434",
    "openrouter": "https://openrouter.ai/api/v1",
    "deepseek": "https://api.deepseek.com/v1",
    "perplexity": "https://api.perplexity.ai",
    "openai": "https://api.openai.com",
}

def get_api_key(provider_name: str) -> Optional[str]:
    """
    Get the API key for a specific provider from environment variables
    
    Args:
        provider_name: Name of the provider
        
    Returns:
        API key for the provider or None if not set
    """
    env_var = API_KEY_ENV_VARS.get(provider_name)
    if env_var:
        return os.getenv(env_var)
    return None

def get_api_base(provider_name: str) -> Optional[str]:
    """
    Get the API base URL for a specific provider
    
    Args:
        provider_name: Name of the provider
        
    Returns:
        API base URL for the provider or None if not set
    """
    return API_BASE_URLS.get(provider_name) 