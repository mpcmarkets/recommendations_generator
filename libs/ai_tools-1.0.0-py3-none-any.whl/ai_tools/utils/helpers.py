from typing import Dict, Any
import json


def pretty_print_json(data: Dict[str, Any]) -> None:
    """
    Pretty print a JSON-serializable dictionary
    
    Args:
        data: Dictionary to print
    """
    print(json.dumps(data, indent=2, ensure_ascii=False))

def truncate_string(text: str, max_length: int = 100) -> str:
    """
    Truncate a string to a maximum length and add ellipsis if needed
    
    Args:
        text: String to truncate
        max_length: Maximum length
        
    Returns:
        Truncated string
    """
    if len(text) <= max_length:
        return text
    return text[:max_length] + "..." 