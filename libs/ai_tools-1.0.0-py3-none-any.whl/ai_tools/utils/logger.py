import logging
import sys

def setup_logger(name, level=logging.INFO):
    """Set up a logger with a specific name and level"""
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # Check if the logger already has handlers to prevent duplicates
    if not logger.handlers:
        # Create console handler with formatting
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        
        # Add the handler to the logger
        logger.addHandler(handler)
    
    # Prevent propagation to root logger to avoid duplicate messages
    logger.propagate = False
    
    return logger 