"""
FAISS vector store implementation that handles in-memory vector search.

This module provides a simple wrapper around FAISS for vector similarity search
with methods to load/save from disk and export/import from PGVector.
"""

import os
from typing import List, Dict, Any, Optional, Tuple

import numpy as np
import faiss
from langchain_community.vectorstores import FAISS as LangchainFAISS
from langchain_core.embeddings import Embeddings

from ..utils.logger import setup_logger
from .metadata import MetadataHandler

logger = setup_logger(__name__)


class FAISSStore:
    """
    Simple wrapper around FAISS for vector similarity search.
    
    Provides a clean interface for adding documents with embeddings,
    searching by vector similarity, and persistence operations.
    """
    
    def __init__(self, 
                embedding_function: Embeddings,
                dimension: int = 1536):
        """
        Initialize a FAISS vector store.
        
        Args:
            embedding_function: Function to generate embeddings for searches
            dimension: Embedding dimension (default: 1536 for OpenAI)
        """
        self.embedding_function = embedding_function
        self.dimension = dimension
        self.langchain_store = None  # Will be initialized on first add
        self.metadata_handler = MetadataHandler()
        
    def add_documents(self, 
                     texts: List[str], 
                     embeddings: List[List[float]], 
                     metadatas: Optional[List[Dict[str, Any]]] = None) -> List[str]:
        """
        Add document texts with pre-computed embeddings to the store.
        
        Args:
            texts: List of document text strings
            embeddings: List of embedding vectors (same length as texts)
            metadatas: Optional list of metadata dictionaries
            
        Returns:
            List of document IDs added
        """
        if len(texts) != len(embeddings):
            raise ValueError(f"Number of texts ({len(texts)}) must match embeddings ({len(embeddings)})")
            
        if metadatas is not None and len(metadatas) != len(texts):
            raise ValueError(f"Number of metadata items ({len(metadatas)}) must match texts ({len(texts)})")
            
        # Create text-embedding pairs required by Langchain FAISS
        text_embedding_pairs = list(zip(texts, embeddings))
        
        # Process and normalize metadata
        processed_metadatas = []
        if metadatas:
            for i, metadata in enumerate(metadatas):
                # Add embedding dimension if not present
                updated_metadata = dict(metadata)
                updated_metadata["embedding_dimension"] = self.dimension
                
                # Generate document_id and chunk_id if not provided
                doc_id = updated_metadata.get("document_id", f"doc_{i}")
                chunk_id = updated_metadata.get("chunk_id", f"chunk_{i}")
                
                # Normalize and convert to FAISS format
                normalized = self.metadata_handler.normalize(
                    metadata=updated_metadata,
                    document_id=doc_id,
                    chunk_id=chunk_id
                )
                processed_metadatas.append(self.metadata_handler.convert_to_faiss_format(normalized))
        else:
            # Create basic metadata if none provided
            for i in range(len(texts)):
                normalized = self.metadata_handler.normalize(
                    metadata={"embedding_dimension": self.dimension},
                    document_id=f"doc_{i}",
                    chunk_id=f"chunk_{i}"
                )
                processed_metadatas.append(self.metadata_handler.convert_to_faiss_format(normalized))
        
        # Check if we need to initialize the store
        if self.langchain_store is None:
            logger.info(f"Initializing FAISS store with {len(texts)} documents")
            self.langchain_store = LangchainFAISS.from_embeddings(
                text_embeddings=text_embedding_pairs,
                embedding=self.embedding_function,
                metadatas=processed_metadatas
            )
            # Convert dictionary to list of strings for return type consistency
            return list(self.langchain_store.index_to_docstore_id.values())
            
        # Add to existing store
        logger.info(f"Adding {len(texts)} documents to existing FAISS store")
        added_ids = self.langchain_store.add_embeddings(
            text_embeddings=text_embedding_pairs,
            metadatas=processed_metadatas
        )
        # Convert to list if not already
        return list(added_ids) if isinstance(added_ids, dict) else added_ids
    
    def search(self,
               query_embedding: List[float],
               k: int = 4,
               filter_metadata: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Search for documents by vector similarity.
        
        Args:
            query_embedding: The query vector
            k: Number of results to return
            filter_metadata: Optional metadata filter
            
        Returns:
            List of dictionaries with search results and scores
        """
        if self.langchain_store is None:
            logger.warning("Cannot search: FAISS store not initialized")
            return []
            
        try:
            # Convert filter metadata to FAISS format if provided
            faiss_filter = None
            if filter_metadata:
                faiss_filter = self.metadata_handler.convert_to_faiss_format(filter_metadata)
                
            # Find similar vectors
            docs_and_scores = self.langchain_store.similarity_search_with_score_by_vector(
                embedding=query_embedding,
                k=k,
                filter=faiss_filter
            )
            
            # Convert to standardized result format
            results = []
            for doc, score in docs_and_scores:
                # Extract document contents and metadata
                content = doc.page_content if hasattr(doc, 'page_content') else ""
                metadata = doc.metadata if hasattr(doc, 'metadata') else {}
                
                # Convert metadata back from FAISS format
                standardized_metadata = self.metadata_handler.convert_from_faiss_format(metadata)
                
                # Add to results
                results.append({
                    'content': content,
                    'metadata': standardized_metadata,
                    'score': float(score),  # Ensure score is a Python float
                    'embedding': None  # FAISS doesn't store the embedding
                })
                
            return results
        except Exception as e:
            logger.error(f"Error searching FAISS index: {e}")
            return []
    
    def save_local(self, folder_path: str) -> bool:
        """
        Save the FAISS index to a local directory.
        
        Args:
            folder_path: Directory to save the index
            
        Returns:
            True if successful, False otherwise
        """
        if self.langchain_store is None:
            logger.warning("Cannot save: FAISS store not initialized")
            return False
            
        try:
            os.makedirs(folder_path, exist_ok=True)
            self.langchain_store.save_local(folder_path)
            logger.info(f"FAISS index saved to {folder_path}")
            return True
        except Exception as e:
            logger.error(f"Error saving FAISS index: {e}")
            return False
    
    @classmethod        
    def load_local(cls, 
                  folder_path: str, 
                  embedding_function: Embeddings,
                  allow_dangerous_deserialization: bool = True) -> 'FAISSStore':
        """
        Load a FAISS index from a local directory.
        
        Args:
            folder_path: Directory containing the saved index
            embedding_function: Embedding function to use with the loaded index
            allow_dangerous_deserialization: Allow loading pickled objects
            
        Returns:
            Initialized FAISSStore
        """
        try:
            # Create instance
            store = cls(embedding_function=embedding_function)
            
            # Load the Langchain FAISS store
            store.langchain_store = LangchainFAISS.load_local(
                folder_path=folder_path,
                embeddings=embedding_function,
                allow_dangerous_deserialization=allow_dangerous_deserialization
            )
            
            # Update dimension based on loaded index
            if store.langchain_store and store.langchain_store.index:
                store.dimension = store.langchain_store.index.d
                
            logger.info(f"Loaded FAISS index from {folder_path}")
            return store
            
        except Exception as e:
            logger.error(f"Error loading FAISS index: {e}")
            raise
            
    def export_to_pgvector(self) -> List[Dict[str, Any]]:
        """
        Export documents to a format suitable for PGVector import.
        
        Returns:
            List of document dictionaries ready for PGVector import
        """
        if self.langchain_store is None:
            logger.warning("Cannot export: FAISS store not initialized")
            return []
            
        try:
            export_data = []
            
            # Get document IDs from the docstore
            document_ids = []
            docstore = self.langchain_store.docstore
            
            # Try to safely access document IDs
            try:
                # Access the index_to_docstore_id mapping which should always be available
                document_ids = list(self.langchain_store.index_to_docstore_id.values())
            except Exception as e:
                logger.error(f"Error accessing document IDs: {e}")
                return []
            
            # Process each document by its ID
            for doc_id in document_ids:
                try:
                    # Get the document safely
                    doc = docstore.search(doc_id)
                    
                    # Handle different document types
                    if doc is None:
                        continue
                        
                    # Extract content and metadata safely
                    content = ""
                    metadata = {}
                    
                    if isinstance(doc, str):
                        # Handle string documents
                        content = doc
                    elif hasattr(doc, "page_content"):
                        content = doc.page_content
                    elif isinstance(doc, dict) and "page_content" in doc:
                        content = doc["page_content"]
                        
                    if isinstance(doc, str):
                        # Strings don't have metadata
                        pass
                    elif hasattr(doc, "metadata"):
                        metadata = doc.metadata
                    elif isinstance(doc, dict) and "metadata" in doc:
                        metadata = doc["metadata"]
                    
                    # Process document for export
                    self._process_doc_for_export(doc_id, content, metadata, export_data)
                except Exception as e:
                    logger.warning(f"Error processing document {doc_id}: {e}")
                    continue
            
            logger.info(f"Prepared {len(export_data)} documents for export")
            return export_data
            
        except Exception as e:
            logger.error(f"Error preparing data for export: {e}")
            return []
            
    def _process_doc_for_export(self, doc_id: str, content: str, metadata: Dict[str, Any], export_data: List[Dict[str, Any]]):
        """Helper method to process a document for export to PGVector"""
        # Convert metadata back from FAISS format
        standardized_metadata = self.metadata_handler.convert_from_faiss_format(metadata)
        
        # Ensure document_id and chunk_id exist
        if "document_id" not in standardized_metadata:
            standardized_metadata["document_id"] = doc_id
        if "chunk_id" not in standardized_metadata:
            standardized_metadata["chunk_id"] = f"chunk_{len(export_data)}"
        
        # Generate embedding if content exists
        embedding = None
        if content:
            try:
                embedding = self.embedding_function.embed_query(content)
            except Exception as e:
                logger.warning(f"Error generating embedding for export: {e}")
                return
                
        if not embedding:
            logger.warning(f"No embedding available for document {doc_id}, skipping")
            return
            
        # Add to export data
        export_data.append({
            'document_id': standardized_metadata.get('document_id'),
            'chunk_id': standardized_metadata.get('chunk_id'),
            'content': content,
            'embedding': embedding,
            'metadata': standardized_metadata
        })