"""
Simplified Vector Store Factory for FAISS only
"""

import logging
from typing import Dict, List, Optional, Type, Any
import numpy as np

from ..utils.logger import setup_logger

# Set up logger
logger = setup_logger(__name__)

class VectorStoreFactory:
    """Factory for creating vector stores"""
    
    def __init__(self):
        self.stores = {
            'faiss': self._create_faiss_store,
        }
        logger.info("FAISS vector store available")
    
    def get_store(self, store_type: str, dimension: int = 1536, **kwargs) -> 'FAISSStore':
        """Get a vector store instance"""
        if store_type not in self.stores:
            raise ValueError(f"Unknown vector store type: {store_type}")
        
        return self.stores[store_type](dimension=dimension, **kwargs)
    
    def _create_faiss_store(self, dimension: int = 1536, **kwargs) -> 'FAISSStore':
        """Create a FAISS vector store"""
        try:
            import faiss
            return FAISSStore(dimension=dimension, **kwargs)
        except ImportError:
            raise ImportError("FAISS is required. Install with: pip install faiss-cpu")

class FAISSStore:
    """FAISS vector store implementation"""
    
    def __init__(self, dimension: int = 1536):
        try:
            import faiss
            self.dimension = dimension
            self.index = faiss.IndexFlatL2(dimension)
            self.documents = []
            logger.info(f"Created FAISS store with dimension {dimension}")
        except ImportError:
            raise ImportError("FAISS is required. Install with: pip install faiss-cpu")
    
    def add_documents(self, documents: List[str], embeddings: Optional[List[List[float]]] = None):
        """Add documents to the vector store"""
        if embeddings is None:
            raise ValueError("Embeddings must be provided for FAISS store")
        
        # Convert to numpy array
        embeddings_array = np.array(embeddings).astype('float32')
        
        # Add to index
        self.index.add(embeddings_array)
        
        # Store documents
        self.documents.extend(documents)
        
        logger.info(f"Added {len(documents)} documents to FAISS store")
    
    def search(self, query_embedding: List[float], k: int = 5) -> List[str]:
        """Search for similar documents"""
        if not self.documents:
            return []
        
        # Convert query to numpy array
        query_array = np.array([query_embedding]).astype('float32')
        
        # Search
        distances, indices = self.index.search(query_array, min(k, len(self.documents)))
        
        # Return documents
        results = []
        for idx in indices[0]:
            if idx < len(self.documents):
                results.append(self.documents[idx])
        
        return results
    
    def get_document_count(self) -> int:
        """Get the number of documents in the store"""
        return len(self.documents)
    
    def clear(self):
        """Clear all documents from the store"""
        try:
            import faiss
            self.index = faiss.IndexFlatL2(self.dimension)
            self.documents = []
            logger.info("Cleared FAISS store")
        except ImportError:
            raise ImportError("FAISS is required. Install with: pip install faiss-cpu")
